const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `✳️ Usa el comando así:\n${usedPrefix + command} +50248019799`;

  // Normaliza el número: quita espacios, signos y deja solo dígitos
  const numero = text.replace(/\D/g, '');
  if (numero.length < 8) throw '⚠️ Número no válido.';

  try {
    const url = await conn.profilePictureUrl(numero + '@s.whatsapp.net', 'image');
    await conn.sendFile(m.chat, url, 'perfil.jpg', `📸 Foto de perfil de: +${numero}`, m);
  } catch (e) {
    throw `❌ No se pudo obtener la foto de perfil. El usuario puede no tener foto o haber restringido el acceso.`;
  }
};

handler.command = /^rpf$/i;
export default handler;