const handler = async (m, { conn }) => {
  if (!m.quoted) return conn.reply(m.chat, '💥 Primero responde a un estado de WhatsApp para poder descargar.', m);

  const tipo = m.quoted.mtype || '';
  try {
    const media = await m.quoted.download();

    if (tipo === 'imageMessage') {
      await conn.sendMessage(m.chat, {
        image: media,
        caption: '🖼️ Aquí tienes el estado de WhatsApp ✏️',
      }, { quoted: m });

    } else if (tipo === 'videoMessage') {
      await conn.sendMessage(m.chat, {
        video: media,
        caption: '🎥 Aquí tienes el estado de WhatsApp ✏️',
      }, { quoted: m });

    } else if (tipo === 'audioMessage') {
      await conn.sendMessage(m.chat, {
        audio: media,
        mimetype: 'audio/mp4',
        ptt: true
      }, { quoted: m });

    } else {
      conn.reply(m.chat, '❌ Ese estado no es una imagen, video o audio válido.', m);
    }

  } catch (e) {
    conn.reply(m.chat, '⚠️ No se pudo recuperar el estado. Asegúrate de responder correctamente al mensaje del estado.', m);
  }
};

handler.command = /^get$/i;
export default handler;