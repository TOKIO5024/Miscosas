import yts from 'yt-search';

const handler = async (m, { conn, text, usedPrefix }) => {
  // Reaccionar si no hay texto
  if (!text) {
    await conn.sendMessage(m.chat, {
      react: {
        text: '❌',
        key: m.key
      }
    });
    return conn.reply(m.chat, '⚠️ Ingresa el nombre de la música que quieres buscar.', m);
  }

  // Reaccionar si incluye "cristal caster"
  if (text.toLowerCase().includes('en esta casa no existe fantasmas solo puros recuerdos')) {
    await conn.sendMessage(m.chat, {
      react: {
        text: '☃️',
        key: m.key
      }
    });
  }

  const res = await yts(text);
  const vid = res.videos[0];

  if (!vid) return conn.reply(m.chat, '❌ No se encontró el video.', m);

  const textoInfo = `*Y O U T U B E — P L A Y*\n\n` +
    `» *Título:* ${vid.title}\n` +
    `» *Duración:* ${vid.duration.timestamp}\n` +
    `» *Autor:* ${vid.author.name}\n` +
    `» *Publicado:* ${vid.ago}\n` +
    `» *Enlace:* ${vid.url}`;

  await conn.sendMessage(m.chat, {
    image: { url: vid.thumbnail },
    caption: textoInfo,
    footer: 'POWERED BY Light Yagami Bot',
    buttons: [
      { buttonId: `${usedPrefix}ytmp3 ${vid.url}`, buttonText: { displayText: '🎵 Audio' }, type: 1 },
      { buttonId: `${usedPrefix}ytmp4 ${vid.url}`, buttonText: { displayText: '🎬 Video' }, type: 1 },
      { buttonId: `${usedPrefix}ytmp4doc ${vid.url}`, buttonText: { displayText: '📄 Video Doc' }, type: 1 }
    ],
    headerType: 4
  }, { quoted: m });
};

handler.help = ['play *<texto>*'];
handler.tags = ['dl'];
handler.command = ['play'];
handler.register = true;

export default handler;