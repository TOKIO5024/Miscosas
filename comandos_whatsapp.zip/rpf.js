const handler = async (m, { conn, args }) => {
  const user = args[0];
  if (!user) return m.reply('⚠️ Proporcione un número de usuario. Ejemplo: .rpf 502xxxxxxx');

  try {
    const pp = await conn.profilePictureUrl(user + '@s.whatsapp.net', 'image');
    await conn.sendFile(m.chat, pp, 'perfil.jpg', `📸 Foto de perfil de wa.me/${user}`, m);
  } catch {
    await m.reply('❌ No se pudo obtener la foto de perfil. Asegúrate de que el número sea correcto.');
  }
};
handler.command = /^rpf$/i;
export default handler;