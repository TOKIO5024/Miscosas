<h1 align="center">𝘼𝙠𝙚𝙣𝙤 𝙝𝙞𝙢𝙚𝙟𝙞𝙢𝙖-𝘽𝙊𝙏-MD 💨</h1>
 <p align="center">🌟 déjanos tu super estrella</p>
</p>


<div align="center">
 
[![creador](https://img.shields.io/badge/Dueño-00802f?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/50248019799)
[![Soporte](https://img.shields.io/badge/soporte-00802f?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/51984368849)
[![YouTube](https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@NeoDragon-Beats-BY)
</div>

---

 

#### **`Instalasion desde cluod Shell `**

<details>
 <summary><b> 👉 Click para los ver Comandos</b></summary>

#### **🪄 Instalación manual por cloud Shell**
> copie y peguen en cluod Shell uno por uno 
 ```bash


apt update && apt upgrade && pkg install -y git nodejs ffmpeg imagemagick yarn
```


```bash
git clone https://github.com/TOKIO5025/akeno-Bot && cd akeno-Bot
```

```bash
yarn install && npm install
```

```bash
npm start
```
> ^⁠_⁠^ 
---

#### **🟢 Activar en caso de detenerse en termux**

Si después de instalar el bot en Termux se detiene (pantalla en blanco, pérdida de conexión a Internet, reinicio del dispositivo), sigue estos pasos:

1. Abre Termux y navega al directorio del bot:
    ```bash
    cd akeno-Bot
    ```

2. Inicia el bot nuevamente:
    ```bash
    npm start
    ```

---

#### **🍬 Obtener otro codigo qr en termux**

Si después de instalar el bot en Termux y iniciar la session del bot (el numero se va a soporte, se cierra la conexión o demorastes al conectar), sigue estos pasos:

1. Abre Termux y navega al directorio del bot:
    ```bash
    cd akeno-Bot
    ```

2. Elimina la carpeta kenoSession:
    ```bash
    rm -rf akeno-BotSession
    ```

3. Inicia el bot nuevamente:
    ```bash
    npm start
    ```

---

### ** Para obtener el bot activa  24/7 (termux)**

> comando para obtener la bot 24/7 en termux

```bash
npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs
```

---

</details>


##### **`EdraCloud
Hosting `**

<a
href="https://test.crxsmods.site"><img src="https://qu.ax/DxVXK.jpg" height="125px"></a>

<div align=>

 

<details>
 <summary><b> ❤️servidor EdraCloud
Hosting</b></summary>

* Dash edraCloud[`Dash`](https://test.crxsmods.site)
* Canal de WhatsApp [`Canal EdraCloud

---


</details>




## **`canales de la bot oficial`**

|------|-------------|-------|
| WhatsApp | Canal | [¡Click aquí!](https://whatsapp.com/channel/0029Vaqe1Iv65yDAKBYr6z0A) |
| WhatsApp | de la bot  | [¡Click aquí!](https://whatsapp.com/channel/0029Vaqe1Iv65yDAKBYr6z0A) |
| WhatsApp | Grupo Ofc | [¡Click aquí!](https://chat.whatsapp.com/DmaLM7iLSFKKi7RkqUkv71) |
 

### **`🔱 Propietario`**
<a
href="https://github.com/TOKIO5025"><img src="https://files.catbox.moe/4n2gjp.jpg" width="130" height="130" alt="TOKIO5025"/></a>

</a> 

### **`colaborador`**
<a
href="https://github.com/emer819adri"><img src="https://github.com/emer819adri.png" width="140" height="140" alt="emer819adri"/></a>


[〘Powered By Team Infinite mods 〙]
