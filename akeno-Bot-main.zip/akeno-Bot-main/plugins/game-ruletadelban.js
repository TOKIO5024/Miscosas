let handler = async (m, { conn, groupMetadata }) => {
    // Verificar si el bot tiene restricciones
    let bot = global.db.data.settings[conn.user.jid] || {};
    if (!bot.restrict) return m.reply(`⚠️ Este comando está desactivado por el dueño del bot.`);

    // Verificar si el mensaje es en un grupo
    if (!m.isGroup) return m.reply(`⚠️ Este comando solo se puede usar en grupos.`);

    // Verificar si el usuario que envía el mensaje es administrador
    const participant = groupMetadata.participants.find(p => p.id === m.sender);
    if (!participant?.admin && groupMetadata.owner !== m.sender) {
        return m.reply(`⚠️ Solo los administradores del grupo pueden usar este comando.`);
    }

    // Función para verificar si un usuario es administrador o el dueño del grupo
    const isAdmin = (participant) => {
        return participant.admin === 'admin' || participant.admin === 'superadmin' || participant.id === groupMetadata.owner;
    };

    // Filtrar participantes (no incluir al bot ni a los administradores)
    let psmap = groupMetadata.participants
        .filter(v => v.id !== conn.user.jid && !isAdmin(v))
        .map(v => v.id);

    // Verificar si hay candidatos
    if (psmap.length === 0) return m.reply(`⚠️ No se encontraron candidatos para la ruleta o todos son administradores.`);

    // Elegir un usuario al azar
    let user = psmap[Math.floor(Math.random() * psmap.length)];

    // Formatear menciones
    let format = a => '@' + a.split('@')[0];

    // Notificar al usuario elegido y proceder con la eliminación
    m.reply(`*${format(user)} ☠️ Has sido elegido por la ruleta de la muerte*`, null, { mentions: [user] });

    // Esperar 2 segundos antes de eliminar al usuario
    await delay(2000);
    await conn.groupParticipantsUpdate(m.chat, [user], 'remove');
};

handler.command = /^(ruletadelban)$/i;
handler.group = true;
handler.tags = ['game'];
handler.admin = true;
handler.botAdmin = true;
export default handler;

const delay = time => new Promise(res => setTimeout(res, time));