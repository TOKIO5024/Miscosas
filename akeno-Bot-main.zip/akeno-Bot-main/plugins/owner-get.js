let handler = async (m, { conn }) => {
  if (!m.quoted) return conn.reply(m.chat, '📥 Responde a un estado de WhatsApp (foto o video) para descargarlo.', m);

  const tipo = m.quoted.mtype || '';
  if (tipo === 'imageMessage') {
    let media = await m.quoted.download();
    await conn.sendMessage(m.chat, { image: media, caption: '✅ Estado descargado (imagen)' }, { quoted: m });
  } else if (tipo === 'videoMessage') {
    let media = await m.quoted.download();
    await conn.sendMessage(m.chat, { video: media, caption: '✅ Estado descargado (video)' }, { quoted: m });
  } else {
    conn.reply(m.chat, '❌ Solo se pueden descargar imágenes o videos de estados.', m);
  }
};

handler.command = /^get$/i;

export default handler;