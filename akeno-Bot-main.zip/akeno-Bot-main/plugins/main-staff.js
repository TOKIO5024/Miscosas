let handler = async (m, { conn, command, usedPrefix }) => {
let staff = `✨ *EQUIPO DE AYUDANTES*
🤖 *Bot:* ${global.botname}
🌟 *Versión:* ${global.vs}

👑 *Propietario:*

• 🐉𝙉𝙚𝙤𝙏𝙤𝙠𝙮𝙤 𝘽𝙚𝙖𝙩𝙨🐲
🤴 *Rol:* Propietario
📱 *Número:* wa.me/50248019799
✨️ *GitHub:* https://github.com/TOKIO5025

🚀  *Colaboradores:*

• 🐉𝙉𝙚𝙤𝙏𝙤𝙠𝙮𝙤 𝘽𝙚𝙖𝙩𝙨🐲
🦁 *Rol:* Developer
📱 *Número:* Wa.me/50248019799

• Dioneibi 
💻 *Rol:* Soporte 
📱 *Número:* Wa.me/18294868853

• emer
💻 *Rol:* Soporte 
📱 *Número:* Wa.me/
`
await conn.sendFile(m.chat, icons, 'akeno.jpg', staff.trim(), fkontak, true, {
contextInfo: {
'forwardingScore': 200,
'isForwarded': false,
externalAdReply: {
showAdAttribution: true,
renderLargerThumbnail: false,
title: `🥷 Developers 👑`,
body: `✨ Staff Oficial`,
mediaType: 1,
sourceUrl: redes,
thumbnailUrl: icono
}}
}, { mentions: m.sender })
m.react(emoji)

}
handler.help = ['staff']
handler.command = ['colaboradores', 'staff']
handler.register = true
handler.tags = ['main']

export default handler
