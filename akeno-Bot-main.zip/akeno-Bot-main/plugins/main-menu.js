import fs from 'fs'
import fetch from 'node-fetch'
import { xpRange } from '../lib/levelling.js'
const { levelling } = '../lib/levelling.js'
import { promises } from 'fs'
import { join } from 'path'
let handler = async (m, { conn, usedPrefix, usedPrefix: _p, __dirname, text, command }) => {
try {        
/*let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}*/
let { exp, level, role } = global.db.data.users[m.sender]
let { min, xp, max } = xpRange(level, global.multiplier)
let name = await conn.getName(m.sender)
let _uptime = process.uptime() * 1000
let _muptime
if (process.send) {
process.send('uptime')
_muptime = await new Promise(resolve => {
process.once('message', resolve)
setTimeout(resolve, 1000)
}) * 1000
}
let user = global.db.data.users[m.sender]
let muptime = clockString(_muptime)
let uptime = clockString(_uptime)
let totalreg = Object.keys(global.db.data.users).length
let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let mentionedJid = [who]
let perfil = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://i.ibb.co/GtYw361/Yuki.jpg')
let taguser = '@' + m.sender.split("@s.whatsapp.net")[0]
const vid = ['https://qu.ax/eJTic.mp4', 'https://qu.ax/eJTic.mp4', 'https://qu.ax/eJTic.mp4']

let menu = `ᯓᡣ𐭩 𝘼𝙠𝙚𝙣𝙤 𝙝𝙞𝙢𝙚𝙟𝙞𝙢𝙖-𝘽𝙊𝙏-𝓜𝓓 𓏲꯭֟፝੭ ꯭  ꯭𔓕

🐲 ¡𝐇𝐨𝐥𝐚! 𝐂𝐨𝐦𝐨 𝐄𝐬𝐭𝐚𝐬 𝐄𝐥 𝐃𝐢𝐚 𝐃𝐞 𝐇𝐨𝐲 *${taguser}* 𝐒𝐨𝐲 ${global.botname} ${saludo}. 

┏━━━━ • 𝐈𝐍𝐅𝐎 𝐂𝐑𝐄𝐀𝐃𝐎𝐑ᚐ • ━━━
┃ㅹ ⧼👑⧽ *Creador:* 🐉𝙉𝙚𝙤𝙏𝙤𝙠𝙮𝙤 𝘽𝙚𝙖𝙩𝙨🐲
┃ㅹ ⧼🔱⧽ *Modo:* Publico
┃ㅹ ⧼🌠⧽ *Baileys:* Multi Device
┃ㅹ ⧼🤖⧽ *Bot:* ${(conn.user.jid == global.conn.user.jid ? 'Oficial' : 'Sub-Bot')}
┃ㅹ ⧼⏱️⧽ *Activado:* ${uptime}
┃ㅹ ⧼👥⧽ *Usuarios:* ${totalreg}
┗━━━━━━━━━━━━━━━━━━⪩‎‎

‎┏━━━•𝐈𝐍𝐅𝐎 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎•━━━┓ 
┃๏[-ิ_•ิ]๏ ⧼👤⧽ *Cliente:* ${name}
┃๏[-ิ_•ิ]๏ ⧼✨⧽ *Exp:* ${exp}
┃๏[-ิ_•ิ]๏ ⧼🌟⧽ *Nivel:* ${level}
┃๏[-ิ_•ิ]๏ ⧼⚜️⧽ *Rango:* ${role}
┗━━━━━━━━━━━━━━━━━━━⪩

*─ׄ─ׄ─⭒─ׄ─ׅ─ׄ⭒─ׄ─ׄ─⭒─ׄ─ׄ─⭒─ׄ─ׅ──ׄ*
 `【𝕷 𝖎 𝖘 𝖙 𝖆 - 𝕯𝖊 - 𝕮 𝖔 𝖒 𝖆 𝖓 𝖉 𝖔 𝖘】`

┏━━━━ • 𝐼𝑁𝐹𝑂 𝐵𝑂𝑇 • ━━━━┓
┃Ӂ .botreglas
┃Ӂ .menu
┃Ӂ .menujuegos
┃Ӂ .menuanime
┃Ӂ .menuhorny 
┃Ӂ .menuaudios 
┃Ӂ .runtime
┃Ӂ .script
┃Ӂ .staff
┃Ӂ .blocklist
┗━━━━━━━━━━━━━━━━━━⪩

╔═══•| 𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐜𝐢𝐨́𝐧 |•════╗
┃𖥸 .creador
┃𖥸 .editautoresponder
┃𖥸 .owner
┃𖥸 .dash
┃𖥸 .dashboard
┃𖥸 .views
┃𖥸 .database
┃𖥸 .usuarios
┃𖥸 .user
┃𖥸 .ds
┃𖥸 .listprem
┃𖥸 .status
┃𖥸 .solicitud *<mensaje>*
┃𖥸 .sug *<mensaje>*
┃𖥸 .horario
┃𖥸 .skyplus
┃𖥸 .infobot
┃𖥸 .ping
┃𖥸 .reportar
┃𖥸 .sistema
┃𖥸 .speed
┃𖥸 .speedtest
┃𖥸 .reportar
┗━━━━━━━━━━━━━━━━━⪩
┏━━❃「 𝐑𝐞𝐠𝐢𝐬𝐭𝐫𝐨 」❃
┃❋ .reg
┃❋ .unreg
┃❋ .profile
┃❋ .marry
┃❋ .setgenre
┃❋ .delgenre
┃❋ .setbirth
┃❋ .delbirth
┃❋ .setdescription
┃❋ .deldescription
┗━━━━━━━━━━━━━━━━━━━⪩

┏━━━━━━ •𝐃𝐢𝐯𝐞𝐫𝐬𝐢𝐨𝐧• ━━━━━━
┃☬ .amistad
┃☬ .gay <@tag> | <nombre>
┃☬ .lesbiana <@tag> | <nombre>
┃☬ .pajero <@tag> | <nombre>
┃☬ .pajera <@tag> | <nombre>
┃☬ .puto <@tag> | <nombre>
┃☬ .puta <@tag> | <nombre>
┃☬ .manco <@tag> | <nombre>
┃☬ .manca <@tag> | <nombre>
┃☬ .revelargenero *<texto>*
┃☬ .rata <@tag> | <nombre>
┃☬ .prostituta <@tag> | <nombre>
┃☬ .prostituto <@tag> | <nombre> 
┃☬ .consejo
┃☬ .divorce
┃☬ .doxear
┃☬ .doxxing <nombre> | <@tag>
┃☬ .formarpareja
┃☬ .formarpareja5
┃☬ .horny
┃☬ .hornycard
┃☬ .huevo @user
┃☬ .iqtest
┃☬ .marica
┃☬ .meme
┃☬ .aplauso
┃☬ .marron
┃☬ .suicide
┃☬ .chupalo
┃☬ .minovia @user
┃☬ .morse *<encode|decode>*
┃☬ .nombreninja *<texto>*
┃☬ .pajeame
┃☬ .personalidad
┃☬ .piropo
┃☬ .pokedex *<pokemon>*
┃☬ .pregunta
┃☬ .ship
┃☬ .love
┃☬ .simpcard
┃☬ .sorteo
┃☬ .itssostupid
┃☬ .estupido
┃☬ .stupid
┃☬ .top *<texto>*
┃☬ .formartrio @usuario1 @usuario2
┃☬ .waste @user
┃☬ .zodiac *2002 02 25*
┗━━━━━━━❰･❉･❱━━━━━━━━⪩

┏━━━━━━◇jυєgσs◇━━━━━━
┃𖢔 .cancion
┃𖢔 .pista
┃𖢔 .ttt nueva sala 
┃𖢔 .ahorcado
┃𖢔 .math <mode>
┃𖢔 .ppt
┃𖢔 .pvp @user
┃𖢔 .reto
┃𖢔 .sopa
┃𖢔 .verdad
┗━━━━━━━━◇x◇━━━━━━━━━━

┏◤━━━━ ☆.𝐄𝐦𝐨𝐱-𝐀𝐧𝐢𝐦𝐞.☆━━━━━◥
┃𓅂 .angry/enojado @tag
┃𓅂 .bath/bañarse @tag
┃𓅂 .bite/morder @tag
┃𓅂 .bleh/lengua @tag
┃𓅂 .blush/sonrojarse @tag
┃𓅂 .bored/aburrido @tag
┃𓅂 .coffe/cafe @tag
┃𓅂 .cry/llorar @tag
┃𓅂 .cuddle/acurrucarse @tag
┃𓅂 .dance/bailar @tag
┃𓅂 .drunk/borracho @tag
┃𓅂 .eat/comer @tag
┃𓅂 .facepalm/palmada @tag
┃𓅂 .grop/manosear @tag
┃𓅂 .happy/feliz @tag
┃𓅂 .hello/hola @tag
┃𓅂 .hug/abrazar @tag
┃𓅂 .kill/matar @tag
┃𓅂 .kiss/besar @tag
┃𓅂 .kiss2/besar2 @tag
┃𓅂 .laugh/reirse @tag
┃𓅂 .lick/lamer @tag
┃𓅂 .love2/enamorada @tag
┃𓅂 .patt/acariciar @tag
┃𓅂 .poke/picar @tag
┃𓅂 .pout/pucheros @tag
┃𓅂 .preg/embarazar @tag
┃𓅂 .punch/golpear @tag
┃𓅂 .run/correr @tag
┃𓅂 .sad/triste @tag
┃𓅂 .scared/asustada @tag
┃𓅂 .seduce/seducir @tag
┃𓅂 .shy/timida @tag
┃𓅂 .slap/bofetada @tag
┃𓅂 .sleep/dormir @tag
┃𓅂 .smoke/fumar @tag
┃𓅂 .think/pensando @tag
┃𓅂 .undress/encuerar @tag
┗━━━━ ☆. ∆ .☆━━━━━⪩

┏━━━━━━☆𝐇𝐨𝐫𝐧𝐲☆━━━━━━━┓
┃ღ .sixnine/69 @tag
┃ღ .anal/culiar @tag
┃ღ .blowjob/mamada @tag
┃ღ .boobjob/rusa @tag
┃ღ .cum/leche @tag
┃ღ .fap/paja @tag
┃ღ .follar @tag
┃ღ .footjob/pies @tag
┃ღ .fuck/coger @tag
┃ღ .fuck2/coger2 @tag
┃ღ .grabboobs/agarrartetas @tag
┃ღ .penetrar @user
┃ღ .lickpussy/coño @tag
┃ღ .sexo/sex @tag
┃ღ .spank/nalgada @tag
┃ღ .suckboobs/chupartetas @tag
┃ღ .violar/perra @tag
┃ღ .lesbianas/tijeras @tag
┃ღ .rule34 <personaje>
┗━━━━━━ • ✿ • ━━━━━━━┛

┏════ ≪ •𝐑𝐨𝐥𝐥𝐰𝐚𝐢𝐟𝐮𝐬• ≫ ════┓
┃𖧯 .character
┃𖧯 .darrw
┃𖧯 .obtenidos
┃𖧯 .c
┃𖧯 .robarpersonaje
┃𖧯 .rw
┃𖧯 .toprw
╚══════ ≪ •❈• ≫ ══════╝

┏━━━ ஜ•𝐄𝐜𝐨𝐧𝐨𝐦𝐢𝐚 •ஜ━━━━━┓
┃囧 .apostar 
┃囧 .bal
┃囧 .bank
┃囧 .dragones
┃囧 .prestar
┃囧 .deuda
┃囧 .pagar
┃囧 .apostar *<cantidad>*
┃囧 .cf
┃囧 .crimen
┃囧 .depositar
┃囧 .minar
┃囧 .retirar
┃囧 .rob2
┃囧 .rob
┃囧 .ruleta *<cantidad> <color>*
┃囧 .Buy
┃囧 .Buyall
┃囧 .slot <apuesta>
┃囧 .slut
┃囧 .trabajar
┃囧 .transfer [tipo] [cantidad] [@tag]
┗━━━━━ ☆. ∆ .☆ ━━━━━◥

┏━━━━━━━✦𝐑-𝐏-𝐆✦━━━━━━━━┓
┃★ .adventure
┃★ .annual
┃★ .cofre
┃★ .daily
┃★ .claim
┃★ .cazar
┃★ .halloween
┃★ .heal
┃★ .lb
┃★ .levelup
┃★ .inventario 
┃★ .mazmorra
┃★ .monthly
┃★ .navidad
┃★ .addprem [@user] <days>
┃★ .weekly
┗━━━━━━━━━━★━━━━━━━━━━┙

┏━━━━◈𝑆𝐸𝑅𝐵𝑂𝑇◈━━━━━┓
┃✾ .jadibot 
┃✾ .deletebot
┃✾ .bots
┃✾ .stop
┃✾ .serbot
┃✾ .serbot --code 
┃✾ .token
┃✾ .rentbot
┗━━━━━━━━━━━━━━━━━┙

┏━━━━━━◆𝐁𝐮𝐬𝐜𝐚𝐝𝐨𝐫𝐞𝐬◆━━━━━━━┓
┃⚔ .animesearch
┃⚔ .appstore
┃⚔ .bingsearch
┃⚔ .cuevana
┃⚔ .githubsearch
┃⚔ .gimage
┃⚔ .gnula
┃⚔ .googlesearch *<texto>*
┃⚔ .npmjs
┃⚔ .steam
┃⚔ .twitterstalk <username>
┃⚔ .tiktoksearch <txt>
┃⚔ .tweetposts *<búsqueda>*
┃⚔ .wikis
┃⚔ .xnxxsearch <query>
┃⚔ .ytsearch
┃⚔ .imagen <query>
┃⚔ .infoanime
┃⚔ .animelink
┗━━━━━━━━╗✹╔━━━━━━━━━┙

┏•━•━•━ 𝐃𝐞𝐬𝐜𝐚𝐫𝐠𝐚𝐬 ━•━•━•┓
┃ᯓᡣ𐭩 .animedl
┃ᯓᡣ𐭩 .animeinfo
┃ᯓᡣ𐭩 .apk2
┃ᯓᡣ𐭩 .apkmod
┃ᯓᡣ𐭩 .facebook
┃ᯓᡣ𐭩 .fb
┃ᯓᡣ𐭩 .gdrive
┃ᯓᡣ𐭩 .gitclone *<url git>*
┃ᯓᡣ𐭩 .instagram2
┃ᯓᡣ𐭩 .ig2
┃ᯓᡣ𐭩 .imagen <query>
┃ᯓᡣ𐭩 .mangad <nombre del manga> <número del capítulo>
┃ᯓᡣ𐭩 .mediafire
┃ᯓᡣ𐭩 .mega
┃ᯓᡣ𐭩 .npmdl
┃ᯓᡣ𐭩 .aptoide
┃ᯓᡣ𐭩 .pinterest
┃ᯓᡣ𐭩 .pinvid
┃ᯓᡣ𐭩 .play
┃ᯓᡣ𐭩 .play2
┃ᯓᡣ𐭩 .play3
┃ᯓᡣ𐭩 .play4
┃ᯓᡣ𐭩 .playdoc
┃ᯓᡣ𐭩 .playdoc2
┃ᯓᡣ𐭩 .mp3
┃ᯓᡣ𐭩 .mp4
┃ᯓᡣ𐭩 .tiktokrandom
┃ᯓᡣ𐭩 .spotify
┃ᯓᡣ𐭩 .tiktokimg <url>
┃ᯓᡣ𐭩 .tiktokmp3 *<link>*
┃ᯓᡣ𐭩 .tiktok
┃ᯓᡣ𐭩 .tiktok2 *<link>*
┃ᯓᡣ𐭩 .wallpaper <query>
┃ᯓᡣ𐭩 .tw
┃ᯓᡣ𐭩 .ss2
┃ᯓᡣ𐭩 .ssvid
┗━━━━━━━━━━━━━━━━━

┏━━━━━ ★𝐀𝐢/𝐈𝐚 ★━━━━━━━━
┃☫ .demo
┃☫ .gemini
┃☫ .goku
┃☫ .bot
┗━━━━━━━━━━━━━━━━━⪩

┏━━━━ • 𝐆𝐫𝐮𝐩𝐨𝐬 • ━━━━┓
┃♕ .add
┃♕ admins <texto>
┃♕ .bienvenidos/nuevos
┃♕ .nights/noches
┃♕ .dias/days
┃♕ .grupotime *<open/close>* *<número>*
┃♕ .grupo abrir / cerrar
┃♕ .delete
┃♕ .demote
┃♕ .encuesta <text|text2>
┃♕ .hidetag
┃♕ .infogrupo
┃♕ .invite *<numero>*
┃♕ .kick
┃♕ .listonline
┃♕ .link
┃♕ .listadv
┃♕ .promote
┃♕ .rentar
┃♕ .rentar2 *<link>*
┃♕ .revoke
┃♕ .setbye <text>
┃♕ .Setdesc <text>
┃♕ .setname <text>
┃♕ .setppgrup
┃♕ .setwelcome <text>
┃♕ .tagall *<mesaje>*
┃♕ .invocar *<mesaje>*
┗━━━━━━━━━━━━━━━━━⪩

┏═════ஜ𝐇𝐞𝐫𝐫𝐚𝐦𝐢𝐞𝐧𝐭𝐚𝐬ஜ═════
┃✰ .cal *<ecuacion>*
┃✰ .clima *<lugar>*
┃✰ .fake
┃✰ .getbio *@tag*
┃✰ .getname *@tag*
┃✰ .remini
┃✰ .hd
┃✰ .enhance
┃✰ .nuevafotochannel
┃✰ .nosilenciarcanal
┃✰ .silenciarcanal
┃✰ .noseguircanal
┃✰ .seguircanal
┃✰ .avisoschannel
┃✰ .resiviravisos
┃✰ .inspect
┃✰ .inspeccionar
┃✰ .eliminarfotochannel
┃✰ .reactioneschannel
┃✰ .reaccioneschannel
┃✰ .nuevonombrecanal
┃✰ .nuevadescchannel
┃✰ .IPdoxx
┃✰ .photo <query>
┃✰ .readmore *<teks>|<teks>*
┃✰ .ver
┃✰ .reenviar
┃✰ .spamwa <number>|<mesage>|<no of messages>
┃✰ .ssweb
┃✰ .ss
┃✰ .tamaño *<cantidad>*
┃✰ .document *<audio/video>*
┗━━━━━━━━━━━━━━━━━⪩

┏══━━━━✥𝐂𝐨𝐧𝐯𝐞𝐫𝐭𝐢𝐝𝐨𝐫𝐞𝐬ᚐ✥━━━━══
┃ꕥ .ibb
┃ꕥ .paste nombre txt
┃ꕥ .to <reply image>
┃ꕥ .toanime
┃ꕥ .togifaud
┃ꕥ .tourl
┃ꕥ .tovideo
┃ꕥ .tts <lang> <teks>
┃ꕥ .tts2
┃ꕥ .tourl2
┗━━━━━━━━━━━━━━━━━⪩

┏═════ ♢.𝐒𝐭𝐢𝐜𝐤𝐞𝐫𝐬.♢ ═════┓
┃☠︎︎ .emojimix *<emoji+emoji>*
┃☠︎︎ .pfp
┃☠︎︎ .qc
┃☠︎︎ .stiker <img>
┃☠︎︎ .sticker <url>
┃☠︎︎ .toimg (reply)
┃☠︎︎ .take *<nombre>|<autor>*
┗━━━━━━━━━━━━━━━━━⪩

╔═════  𝐂𝐨𝐧𝐟𝐢𝐠𝐮𝐫𝐚𝐜𝐢𝐨́𝐧  ═════╗
┃⚘ .enable <option>
┃⚘ .disable <option>
┃⚘ .autoadmin
┃⚘ .banchat
┃⚘ .banuser <@tag> <razón>
┃⚘ .grupocrear <nombre>
┃⚘ .join <link>
┃⚘ .unbanchat
┃⚘ .unbanuser <@tag>
┗━━━━━━━━━━━━━━━━━⪩

┏━━━━• 𝐂𝐫𝐞𝐚𝐝𝐨𝐫/𝐎𝐰𝐧𝐞𝐫 •━━━━┓
┃🜲 .listafk
┃🜲 .expired *<días>*
┃🜲 .addyenes *<@user>*
┃🜲 .addprem [@user] <days>
┃🜲 .copia
┃🜲 .broadcast
┃🜲 .bc
┃🜲 .broadcastgroup
┃🜲 .bcgc
┃🜲 .bcgc2
┃🜲 .cleanfiles
┃🜲 .cleartmp
┃🜲 .setcmd *<texto>*
┃🜲 .deletefile
┃🜲 .delexpired
┃🜲 .delvn <text>
┃🜲 .delmsg <text>
┃🜲 .delimg <text>
┃🜲 .delsticker <text>
┃🜲 .delprem <@user>
┃🜲 .reunion *<texto>*
┃🜲 .removeowner @user
┃🜲 .dsowner
┃🜲 .$
┃🜲 .fetch
┃🜲 .get
┃🜲 .getplugin *<nombre>*
┃🜲 .groups
┃🜲 .grouplist
┃🜲 .kickall @user
┃🜲 .nuevabiobot <teks>
┃🜲 .nuevafotobot *<imagen>*
┃🜲 .nuevonombrebot <teks>
┃🜲 .prefix [prefix]
┃🜲 .resetpersonajes
┃🜲 .resetprefix
┃🜲 .restart
┃🜲 .saveplugin nombre
┃🜲 .update
┃🜲 .actualizar
┃🜲 >
┃🜲 =>
┗━━━━━━━━━━━━━━━━━⪨
> 𝓟𝓞𝓦𝓔𝓡𝓓 𝓑𝓨 🐉𝙉𝙚𝙤𝙏𝙤𝙠𝙮𝙤 𝘽𝙚𝙖𝙩𝙨🐲`.trim()

await conn.sendMessage(m.chat, { video: { url: vid.getRandom() }, caption: menu, contextInfo: { mentionedJid: [m.sender], isForwarded: true, forwardedNewsletterMessageInfo: { newsletterJid: channelRD.id, newsletterName: channelRD.name, serverMessageId: -1, }, forwardingScore: 999, externalAdReply: { title: '𝘼𝙠𝙚𝙣𝙤 𝙝𝙞𝙢𝙚𝙟𝙞𝙢𝙖-𝘽𝙊𝙏', body: dev, thumbnailUrl: perfil, sourceUrl: redes, mediaType: 1, renderLargerThumbnail: false,
}, }, gifPlayback: true, gifAttribution: 0 }, { quoted: null })
await m.react(emojis)    

} catch (e) {
await m.reply(`✘ Ocurrió un error al enviar el menú\n\n${e}`)
await m.react(error)
}}

handler.help = ['menu']
handler.tags = ['main']
handler.command = ['menu', 'help', 'men', 'menú', 'allmenú', 'allmenu', 'menucompleto'] 
handler.register = true
export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)
function clockString(ms) {
let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')}
